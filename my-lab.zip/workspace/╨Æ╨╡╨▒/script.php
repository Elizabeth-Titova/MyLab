<?php
    $db_host = "localhost";
    $db_user = "elizabethtitova";
    $db_password = "";
    $db_base = "FantasticBeasts";
    $link = mysql_connect($db_host, $db_user, $db_password);
    mysql_select_db ($db_base,$link) or die ("Нет соединения с БД".mysql_error());
    mysql_query("SET names UTF-8");
?>
