<?php
    $db_host = "localhost";
    $db_user = "elizabethtitova";
    $db_password = "";
    $db_base = "FantasticBeasts";
    $link = mysql_connect($db_host, $db_user, $db_password);
    mysql_select_db ($db_base,$link) or die ("Нет соединения с БД".mysql_error());
    mysql_query("SET names 'utf8'");
    $post_id = $_GET['post_id'];
?>
<html lang="en-us">

<head>
	<meta charset="utf-8">
	<title>FantasticBeasts</title>
	</head>
	<link rel ="stylesheet" href="element.css">
<body>
<?php
			 
				$result = mysql_query(" SELECT * From table_beasts WHERE ID='$post_id'", $link);
				if (mysql_num_rows($result)>0)
				{
				$row = mysql_fetch_array($result);
				if($row["Print"] == 1)
					{
						do 
						{
				 		echo '
				 		<div class="block">
						<div class="container">
						<div class="element">
						<img src = "'.$row["Image"].'"/>
						<div class="element">
						<h3>'.$row["Name"].'</h3>
						<p>'.$row["Description"].'</p>
						<h3> Подробнее </h3>
						<p>'.$row["FullDescription"].'</p>
						<h3>Тип</h3>
						<p>'.$row["Type"].'</p>
						<h3>Близкие виды</h3>
						<p>'.$row["SimilarSpecies"].'</p>
						<h3>Место обитания</h3>
						<p>'.$row["Geography"].'</p>
						<h3>Особенности</h3>
						<p>'.$row["РartQualities"].'</p>
						<h3>Размер</h3>
						<p>'.$row["Size"].'</p>
						<h3>Цвет</h3>
						<p>'.$row["Color"].'</p>
						<h3>Уровень опасности</h3>
						<p>'.$row["KMM"].'</p>
				 	<a href="index.php"> Назад </a>
				 	</div>
				 	</div>
				 	</div>
				 	' ;
					
				 } while($row = mysql_fetch_array($result));
				}
			}

?>
			
</body>
</html>