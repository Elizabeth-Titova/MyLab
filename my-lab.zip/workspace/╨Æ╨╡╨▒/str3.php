<html lang="en-us">

<head>
<meta charset="utf-8">
<link rel ="stylesheet" href="str2.css">
<title>FantasticBeasts</title>
</head>
<body> 
	<div class="head"> 
	<ul class="menu"> 
		<li>
		<a href="index.php">Галерея  Волшебных Животных</a>
		</li><li>
		<a href="str2.html">О фильме</a>
		</li><li>
		<a class ="active" href="str3.php">Зоологам</a>
		</li>
	</ul> </div> 
	<div class="about"> 
		<h1>Предложите ещё одно животное в нашу энциклопедию</h1>
		<div class="column">
		<p>Если вы магозоолог и у вас есть информация об ещё одном волшебном животном, то заполните форму и мы добавим животное в нашу электронную энциклопедию </p>
		<form action="action.php" method="post" class="form">
			<p>	<input type="text" size = 50 placeholder="Введите ваше имя" name="Mago-zoologist"/></p>
			<p> <input type="text" size = 50  placeholder="Название животного" name="Name"/></p>
			<p> <input type="text" size = 50  placeholder="Ссылка на изображение животного" name="Image"/></p>
			<p> <textarea type="text" cols="52" rows="20" placeholder="Краткое описание" name="Description"></textarea></p> 
			<p> <textarea type="text" cols="52" rows="20" placeholder="Полное описание" name="FullDescription"></textarea></p>
			<p> <input type="text" size = 50  placeholder="К Какому виду относится животное" name="Type"/></p>
			<p> <input type="text" size = 50 placeholder="Места обитания" name="Geography"/></p>
			<p> <textarea type="text" cols="52" rows="20"  placeholder="Особенности" name="РartQualities"></textarea></p>
			<p> <input type="text" size = 50 placeholder="Размер" name="Size"/></p>
			<p> <input type="text" size = 50 placeholder="Цвет" name="Color"/></p>
			<p> <input type="text" size = 50 placeholder="Уровень опасности по КММ" name="KMM"/></p>
			<p><input type="text" size = 50 placeholder="Сходые виды" name="SimilarSpecies"/></p>
			<p><input type="submit" value="Отправить" name= "Add"/></p> 
		
		</form>
	</div>
</div>
</body> 
</html>
