<?php
    $db_host = "localhost";
    $db_user = "elizabethtitova";
    $db_password = "";
    $db_base = "FantasticBeasts";
    $link = mysql_connect($db_host, $db_user, $db_password);
    mysql_select_db ($db_base,$link) or die ("Нет соединения с БД".mysql_error());
    mysql_query("SET names 'utf8'");
?>
<html lang="en-us">

<head>
<meta charset="utf-8">
<link rel ="stylesheet" href="str1.css">
<title>FantasticBeasts</title>
</head>
<body>
	<ul class="menu">
		<li>
		<a class ="active" href="index.php">Галерея  Волшебных Животных</a>
		</li><li>
		<a  href="str2.html">О фильме</a>
		</li><li>
		<a href="str3.php">Зоологам</a>
		</li>
	</ul>	
	<div>
		
				
				<?php
					$result = mysql_query(" SELECT ID, Name, Description, Image, Print From table_beasts", $link);
				if (mysql_num_rows($result)>0)
				{
				$row = mysql_fetch_array($result);
				
						do 
						{
						echo '
				 		<div class="col">
						<div class="">
				 		<div>
				 	
						<img src = "'.$row["Image"].'"/>
				 		<div class ="col-text"> 
				 		<p>'.$row["Name"].' </p>
				 		<div> '.$row["Description"].' </div>
				 		<a href="item.php?post_id='.$row["ID"].'">Подробнее...  </a>
				 		</div>
				 		</div>
				 		</div>
				 		</div>
				 		' ;
				 		} while($row = mysql_fetch_array($result) and ($row["Print"] == 1));
					}
				?>	
				
		
	</div>
</body>
</html>
