<html lang="en-us">

<head>
<meta charset="utf-8">
<link rel ="stylesheet" href="str2.css">
<title>FantasticBeasts</title>
</head>
<body> 
	<div class="head"> 
	<ul class="menu"> 
		<li>
		<a href="index.php">Галерея  Волшебных Животных</a>
		</li><li>
		<a href="str2.html">О фильме</a>
		</li><li>
		<a class ="active" href="str3.php">Зоологам</a>
		</li>
	</ul> </div> 
	<div class="about"> 
		<h1>Результат добавления в энциклопедию</h1>
		<div class="column">
		
<?php
    $db_host = "localhost";
    $db_user = "elizabethtitova";
    $db_password = "";
    $db_base = "FantasticBeasts";
    $link = mysql_connect($db_host, $db_user, $db_password);
    mysql_select_db ($db_base,$link) or die ("Нет соединения с БД".mysql_error());
    mysql_query("SET names 'utf8'");

    $name = $_POST['Name'];
    $image = $_POST['Image'];
    $desk = $_POST['Description'];
    $fdesk = $_POST['FullDescription'];
    $type = $_POST['Type'];
    $geo = $_POST['Geography'];
    $PQual = $_POST['РartQualities'];
    $size = $_POST['Size'];
    $color = $_POST['Color'];
    $kmm = $_POST['KMM'];
    $Ssp=$_POST['SimilarSpecies'];
    $user = $_POST['Mago-zoologist'];

 
    $res=mysql_query("INSERT INTO table_beasts (Name,Image, Description,FullDescription,Type, Geography, РartQualities, Size, Color, KMM,
    SimilarSpecies, User, Print)
    VALUES ('$name','$image','$desk','$fdesk', '$type', '$geo', '$PQual', '$size', '$color', '$kmm', '$Ssp', '$user', 0 );"); 
    if ($res){
        echo "Записано в БД";
    }
    else {
        echo "Не записано в БД";
    }
    mysql_close();
    
 ?>
</div>
</div>
</body> 
</html>
