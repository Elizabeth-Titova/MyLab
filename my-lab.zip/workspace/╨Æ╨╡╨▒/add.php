<?php
    $db_host = "localhost";
    $db_user = "elizabethtitova";
    $db_password = "";
    $db_base = "FantasticBeasts";
    $link = mysql_connect($db_host, $db_user, $db_password);
    mysql_select_db ($db_base,$link) or die ("Нет соединения с БД".mysql_error());
    mysql_query("SET names cp1251");
?>
<html lang="en-us">

<head>
<meta charset="utf-8">
<link rel ="stylesheet" href="str2.css">
<title>FantasticBeasts</title>
</head>
<body> 
	<div class="head"> 
	<ul class="menu"> 
		<li>
		<a href="index.php">Галерея  Волшебных Животных</a>
		</li><li>
		<a href="str2.html">О фильме</a>
		</li><li>
		<a class ="active" href="str3.php">Магозоологам</a>
		</li>
		</ul> </div> 
	<div class="about"> 
    <pre><?php print_r($_POST) ?></pre>
    <?php
    $name = $_POST['Name'];
    $desk = $_POST['Description'];
    $fdesk = $_POST['FullDescription'];
    $type = $_POST['Type'];
    $geo = $_POST['Geography'];
    $PQual = $_POST['РartQualities'];
    $size = $_POST['Size'];
    $color = $_POST['Color'];
    $kmm = $_POST['KMM'];
    $Ssp=$_POST['SimilarSpecies'];
    $user = $_POST['Mago-zoologist'];
    if (isset($_POST['Add']))
    {
         mysql_query("INSERT into User_beasts (Name, Description,FullDescription,Type, Geography, РartQualities, Size, Color, KMM, SimilarSpecies, User)
    VALUES('$name','$desk','$fdesk', '$type', '$geo', '$PQual', '$size', '$color', '$kmm', '$Ssp', '$user')");
    mysql_close();
    echo 'Животное добавлено'
    }
   
    ?>
  </div>
  </body>
</html>